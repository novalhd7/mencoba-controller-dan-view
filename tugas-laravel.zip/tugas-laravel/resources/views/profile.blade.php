<!DOCTYPE html>
<html>
<head>
    <title>profile pembuat</title>
</head>
<body>
    <h1>Perkenalkan nama saya Noval Hidayat</h1></br>
    <h2>saya merupakan peserta studi independen GITS</h2><br>
    <h3>saya berkuliah di Universitas Andalas</h3>

</body>
</html>