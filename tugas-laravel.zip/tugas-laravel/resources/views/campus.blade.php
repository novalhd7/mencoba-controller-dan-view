<!DOCTYPE html>
<html>
<head>
    <title>Informasi Kampus</title>
</head>
<body>
    <p>Universitas Andalas adalah sebuah universitas yang terletak di Kota Padang, Sumatra Barat, Indonesia. Ini adalah salah satu universitas tertua dan terkemuka di Indonesia. Universitas Andalas didirikan pada tanggal 13 Juni 1955.

Universitas Andalas menawarkan berbagai program pendidikan tinggi di berbagai bidang ilmu, termasuk ilmu sosial, ilmu alam, kedokteran, teknik, ekonomi, dan banyak lagi. Universitas ini telah berperan penting dalam mengembangkan pendidikan, penelitian, dan kontribusi pada pengembangan masyarakat di wilayah Sumatra Barat dan Indonesia secara keseluruhan.</p>

</body>
</html>