<!DOCTYPE html>
<html>
<head>
    <title>Halaman Depan</title>
</head>
<body>
    <h1>Selamat Datang di website saya</h1>
    <a href="<?php echo e(route('profile')); ?>">Profile Pembuat</a>
    <a href="<?php echo e(route('campus')); ?>">Informasi Kampus</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\tugas-laravel\resources\views/frontpage.blade.php ENDPATH**/ ?>